(function() {

	var app = angular.module("books", []);

	var MainController = function($scope, $http) {

		var listOfBooks = function(response) {
			console.log("Inside listOfBooks");
			$scope.users = response.data;
		};

		var onError = function(reason) {
			$scope.error = "Could not fetch the Book list";
			$scope.reason = reason;
		};

		$http.get("http://localhost:8080/api/v1/books").then(listOfBooks,
				onError);

	};

	app.controller("MainController", [ "$scope", "$http", MainController ]);

}());