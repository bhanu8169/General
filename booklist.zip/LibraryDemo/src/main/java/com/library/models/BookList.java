package com.library.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class BookList {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
private Long sId;
private String sName;
private String sAuthor;

public String getsAuthor() {
	return sAuthor;
}

public void setsAuthor(String sAuthor) {
	this.sAuthor = sAuthor;
}

public BookList() { }

public BookList(Long sId, String sName, String sAuthor) {
	this.sId = sId;
	this.sName = sName;
	this.sAuthor=sAuthor;
}
public Long getsId() {
	return sId;
}
public void setsId(Long sId) {
	this.sId = sId;
}
public String getsName() {
	return sName;
}
public void setsName(String sName) {
	this.sName = sName;
}


}
