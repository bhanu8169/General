package com.library.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.library.models.BookList;


public class BookStub {
	private static Map<Long, BookList> bookmap = new HashMap<Long, BookList>();
	private static Long idIndex = 6L;

	//populate initial bookmap
	static {
		BookList a = new BookList(1L,"Pride and prejudice","albert");
		bookmap.put(1L, a);
		BookList b = new BookList(2L, "The stranger","bhanu");
		bookmap.put(2L, b);
		BookList c = new BookList(3L, "The road","philip");
		bookmap.put(3L, c);
		BookList d = new BookList(4L, "The Moon","Robin");
		bookmap.put(4L, d);
		BookList e = new BookList(5L, "The Wicked","Jack");
		bookmap.put(5L, e);
		BookList f = new BookList(6L, "The Help","Tyrion");
		bookmap.put(6L, f);
	}

	public static List<BookList> list() {
		return new ArrayList<BookList>(bookmap.values());
	}

	public static BookList create(BookList book) {
		idIndex += idIndex;
		book.setsId(idIndex);
		bookmap.put(idIndex, book);
		return book;
	}

	public static BookList get(Long sId) {
		return bookmap.get(sId);
	}

	public static BookList update(Long sId, BookList book) {
		bookmap.put(sId, book);
		return book;
	}

	public static BookList delete(Long id) {
		return bookmap.remove(id);
	}
}
